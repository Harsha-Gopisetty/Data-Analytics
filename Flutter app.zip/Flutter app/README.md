# Asteroad

### This repository contains code for a  flutter application, asteroad. ###

It's an app that uses NASA's NeoWs API to get information about asteroids that have passed near the earth or are likely to and displays in a simple format.

* To run the app, just clone the repository, and using your favourite IDE, install the app on your phone.It is submitted on account of Data Analytics Lab
